# 活动图片上传修复说明

本次修复：

1. 管理员活动编辑页上传图片后，不再因为从相册/摄像头返回触发活动预告弹窗。
2. 管理员活动编辑页只在首次进入时加载活动数据，选择图片返回后不会重复刷新表单导致刚上传的图片预览丢失。
3. 活动图片上传成功后立即使用本地临时路径预览，不再等待 cloud:// 转临时链接后才显示。
4. 保存活动时同时保存 imageUrl 和 images 数组，读取活动时统一转换为可展示的 imageUrls/displayImageUrl。
5. 首页活动、启动弹窗、活动区、管理员活动列表继续使用 displayImageUrl 显示图片。

需要重新上传部署云函数：

- saveActivityNotice
- getActivityNotice
- getActivityList
