# 默认头像 + 随机昵称增量交付说明（2026-04-20）

## 本次交付目标
- 保留现有项目结构、页面结构、登录体系与 users 集合。
- 微信登录 / 绑定后，前端统一展示项目内默认头像。
- 微信登录 / 绑定后，由后端自动生成随机昵称；若历史用户已有昵称则保留。
- 对历史用户缺失昵称场景做兼容补生成，且不破坏 userId、预约、记录、手机号等关联关系。

## 变更文件
- `miniprogram/assets/images/default-avatar.jpg`
- `miniprogram/utils/profile.js`
- `miniprogram/utils/storage.js`
- `miniprogram/utils/auth.js`
- `miniprogram/pages/login/login.js`
- `miniprogram/pages/login/login.wxml`
- `miniprogram/pages/login/login.wxss`
- `miniprogram/pages/my/my.js`
- `miniprogram/pages/my/my.wxml`
- `miniprogram/pages/my/my.wxss`
- `miniprogram/cloudfunctions/syncUser/index.js`

## 关键实现说明
1. **统一默认头像**
   - 新增默认头像资源：`/assets/images/default-avatar.jpg`
   - 前端展示统一走 `utils/profile.js` 中的默认头像路径。
   - 本地缓存与页面视图通过 `avatarDisplayUrl` 控制展示，不再直接展示数据库中的真实 `avatarUrl`。

2. **随机昵称后端生成**
   - 云函数 `syncUser` 新增随机昵称生成、唯一性校验与重试逻辑。
   - 随机昵称仅使用：`A-Z a-z 0-9 _`
   - 随机长度：8~10 位。
   - 新微信用户首次登录/绑定自动生成昵称。
   - 历史微信用户若无昵称，在 refresh / 登录 / 绑定链路自动补生成。
   - 历史用户若已有昵称，则继续保留，不覆盖。

3. **兼容策略**
   - 不改 `userId`，不动预约、记录、手机号等现有关联字段。
   - `users.avatarUrl` 历史字段可继续保留，但云函数返回给前端的 `avatarUrl` 已统一清空，由前端使用默认头像资源展示。
   - 手机号登录逻辑保持原有流程，仅在已绑定微信但无昵称的历史账号上自动补昵称。

## 建议验证步骤
1. 新微信用户登录：检查“我的”页显示默认头像和随机昵称。
2. 老微信用户（已有昵称）登录：检查昵称保持不变，头像改为默认头像。
3. 老微信用户（无昵称）登录：检查后端自动补生成昵称。
4. 手机号用户绑定微信：检查原账号不变，绑定后显示默认头像与随机昵称。
5. 检查预约、历史记录、管理员入口、手机号绑定逻辑均可正常使用。
4. **返回头像字段脱敏**
   - 预订相关云函数共享 `bookingService` 已同步将 `avatarUrl` 置空，避免其它前端页面后续直接拿到真实头像地址。

