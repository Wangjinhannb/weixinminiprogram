# 活动取消报名同步修复（2026-05-24）

本次修复：

- 取消报名时，按“当前用户 + 当前活动”批量取消所有历史有效报名，避免管理员端残留重复报名记录。
- 管理员活动报名列表按“用户 + 活动 + 手机号”取最新状态；如果最新状态是已取消，则管理员端不再显示。
- 我的活动报名列表按活动取最新状态；取消后不再因为历史重复记录又显示为已报名。
- 重新报名时只保留最新一条为有效报名，并自动把历史重复记录置为已取消。
- 管理员页面前端也增加已取消状态兜底过滤。

需要重新上传部署云函数：

- cancelActivityRegistration
- getAdminActivityRegistrations
- getMyActivityRegistrations
- submitActivityRegistration
