# 增量优化开发交付说明（管理员秒级可预约时间段）

本次继续严格基于现有微信小程序预约系统做增量修改，未重构项目，未新建全新后台系统。

## 本次新增能力

1. 管理员可在现有场室编辑页维护“通用可预约时间段”。
2. 管理员可新增“指定日期覆盖”配置，某一天可覆盖通用时间段。
3. 管理员新增/编辑时间段使用 `picker-view` 滚轮选择器，精确到秒（HH:mm:ss）。
4. 管理员端支持新增、编辑、删除时间段，并在前端即时校验：
   - 结束时间必须大于开始时间
   - 多时间段不可重叠
   - 自动按开始时间排序
5. 后端 `saveVenue` 云函数同步校验以上规则，不能绕过前端直接写入非法配置。
6. 用户端预约页仍保持分钟级滚轮选择，但可选时间会严格受管理员秒级时间段限制。
7. 若管理员为某天配置了单日覆盖，则该日期优先使用单日覆盖；否则回退到通用时间段。
8. 历史 `timeSlots` 的 `HH:mm` 配置会自动补齐为 `HH:mm:ss` 后参与计算；历史 bookings 不受影响。

## 主要修改文件

- `miniprogram/utils/time.js`
- `miniprogram/utils/bookingApi.js`
- `miniprogram/pages/admin_venue_form/admin_venue_form.js`
- `miniprogram/pages/admin_venue_form/admin_venue_form.wxml`
- `miniprogram/pages/admin_venue_form/admin_venue_form.wxss`
- `miniprogram/pages/admin_venues/admin_venues.js`
- `miniprogram/pages/admin_venues/admin_venues.wxml`
- `miniprogram/pages/admin_venues/admin_venues.wxss`
- `miniprogram/pages/booking_form/booking_form.js`
- `miniprogram/pages/booking_form/booking_form.wxml`
- `miniprogram/cloudfunctions/_shared/time.js`
- `miniprogram/cloudfunctions/_shared/bookingService.js`
- `miniprogram/cloudfunctions/saveVenue/index.js`
- `miniprogram/cloudfunctions/createBooking/index.js`
- `miniprogram/cloudfunctions/updateBooking/index.js`
- 所有云函数目录下的 `_shared/time.js`
- 所有云函数目录下的 `_shared/bookingService.js`

## 数据兼容策略

- `venues.timeSlots` 继续保留，作为“通用可预约时间段”字段。
- 新增兼容扩展字段：
  - `bookingTimeConfig.defaultSlots`
  - `bookingTimeConfig.dateOverrides`
- 其中：
  - `timeSlots` 与 `bookingTimeConfig.defaultSlots` 保存同一份通用时段
  - `bookingTimeConfig.dateOverrides` 保存按日期覆盖的时段数组
- 历史只有 `timeSlots` 的场室照常可用。
- 历史 `HH:mm` 时段会在前后端统一补齐为 `HH:mm:ss`。

## 自测建议

1. 管理员编辑某场室，新增通用时段 `09:00:00-12:00:00`、`13:30:15-18:45:30`，保存成功。
2. 管理员尝试新增重叠时段，前端应立即阻止；绕过前端调用 `saveVenue` 时后端也应报错。
3. 给某日期新增覆盖，如 `2026-04-20` 配置 `18:45:31-21:00:00`，预约页选择该日期后应只看到当天覆盖时段。
4. 用户端在 `13:30:15-18:45:30` 场景下：
   - `13:30-14:00` 不可约
   - `13:31-14:00` 可约
   - `18:44-18:45` 可约
   - `18:44-18:46` 不可约
5. 删除单日覆盖最后一个时段时，应提示并删除整个单日覆盖。
6. 历史预约详情、我的预约、管理员预约管理继续正常显示旧 `HH:mm` 预约数据。
