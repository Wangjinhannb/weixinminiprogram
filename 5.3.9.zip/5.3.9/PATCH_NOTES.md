# 预约系统修复说明

## 本次修复覆盖
1. 预约后无法取消
2. 预约详情加载失败
3. 改期不再重复填写预约信息
4. 订阅通知功能不可用
5. 功能室预约时间段逻辑优化

## 新增/调整的数据结构

### bookings（原有集合，建议补充字段）
- `_id`: 预约ID
- `userId`: 预约人ID
- `venueId`: 场室ID
- `venueName`: 场室名称
- `date`: 预约日期，格式 `YYYY-MM-DD`
- `startTime`: 开始时间，格式 `HH:mm`
- `endTime`: 结束时间，格式 `HH:mm`
- `timeLabel`: 展示用时间段
- `form`: 联系人表单对象 `{ name, phone, people, idCard, note }`
- `status`: `active | pending | approved | cancelled | rejected | rescheduled`
- `cancelReason`: 取消原因（可空）
- `cancelledAt`: 取消时间（可空）
- `createdAt` / `updatedAt`

### booking_subscriptions（新增集合）
- `_id`
- `bookingId`
- `userId`
- `enabled`
- `tmplIds`
- `acceptResultMap`
- `createdAt`
- `updatedAt`

### booking_notifications（新增集合）
- `_id`
- `bookingId`
- `userId`
- `type`
- `status`
- `title`
- `content`
- `extra`
- `createdAt`
- `read`

## 新增云函数
- `updateBooking`
- `cancelBooking`
- `getVenueDayBookings`
- `getBookingDetail`
- `saveSubscription`
- `updateBookingStatus`
- `notifyBookingSubscribers`
- `_shared/bookingService.js`（公共逻辑）

## 核心修复点
- 取消预约统一走 `cancelBooking` 云函数，包含权限校验、状态更新、通知落库、前端刷新。
- 详情页增加 `loading / empty / error / success` 四态渲染。
- 改期页面自动回填原预约数据，仅允许修改日期和时间，其他信息只读保留。
- 订阅通知支持：订阅、取消订阅、状态变化落通知记录。
- 时间段从“整天不可约”改为“仅禁用已占用的具体时段”，并在前端置灰禁用。

## 部署建议
1. 在微信云开发控制台创建集合：
   - `bookings`
   - `users`
   - `booking_subscriptions`
   - `booking_notifications`
2. 部署新增/修改后的云函数。
3. 若要接入真正的微信订阅消息推送，可在 `notifyBookingSubscribers` 中追加发送逻辑。
