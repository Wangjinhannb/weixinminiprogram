# 分钟级预约增量优化交付说明

## 本次改造目标
- 保留原有微信小程序 + 云开发 + 云函数 + 云数据库项目结构
- 在现有预约流程上增量升级为分钟级预约
- 预约日期保留原逻辑
- 开始/结束时间改为滚轮式选择，精确到分钟
- 兼容历史整点预约数据与旧的 timeSlots 配置

## 已完成内容
1. 预约页时间选择由固定按钮改为滚轮式选择器（小时 + 分钟）
2. 基于现有 timeSlots 自动合并连续时间段，形成真实开放时间范围
3. 结束时间自动过滤为“晚于开始时间、未超出开放时间、未跨越已占用区间”的合法时间
4. 已占用时间展示改为真实区间展示
5. 前端提交前实时校验非法区间与冲突
6. createBooking / updateBooking / getVenueDayBookings 升级为分钟级规则
7. 云函数与前端新增统一时间工具函数，确保口径一致
8. 历史 bookings 中的整点 HH:mm 数据继续兼容显示与冲突判断

## 重点兼容策略
- 旧 timeSlots 若按 09:00-10:00 / 10:00-11:00 这种整点分段配置，前后端会自动合并为 09:00-12:00 这样的可预约开放范围
- 历史 bookings 仍按 startTime / endTime 的 HH:mm 字符串读取，不改表结构
- 冲突判断统一采用：newStart < oldEnd && newEnd > oldStart

## 本次主要修改文件
- miniprogram/utils/time.js
- miniprogram/pages/booking_form/booking_form.js
- miniprogram/pages/booking_form/booking_form.wxml
- miniprogram/pages/booking_form/booking_form.wxss
- miniprogram/cloudfunctions/createBooking/index.js
- miniprogram/cloudfunctions/updateBooking/index.js
- miniprogram/cloudfunctions/getVenueDayBookings/index.js
- miniprogram/cloudfunctions/_shared/time.js
- miniprogram/cloudfunctions/_shared/bookingService.js
- miniprogram/cloudfunctions/*/_shared/bookingService.js
- miniprogram/cloudfunctions/*/_shared/time.js

## 部署建议
1. 替换小程序前端代码后重新编译
2. 将 createBooking / updateBooking / getVenueDayBookings 及其 _shared 目录重新上传部署
3. 推荐同步上传全部云函数目录中的 _shared 文件，保证本地源码一致
4. 使用下列场景重点回归：
   - 09:15 - 10:40 合法预约
   - 结束时间早于开始时间
   - 超出开放时间预约
   - 与 09:20 - 10:10 冲突的预约
   - 历史整点预约详情显示
