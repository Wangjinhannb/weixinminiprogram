# 活动报名字段增量说明（2026-06-06）

## 本次需求

在不改变原有活动报名打开、关闭、登录校验、提交、取消和管理员查看逻辑的基础上：

1. 活动报名弹层卡片加大。
2. 报名表新增必填「姓名」。
3. 报名表新增必选「是否带小孩」。
4. 管理员端「活动报名信息」可看到姓名、手机号、报名人数、是否带小孩。

## 是否需要新建云函数

不需要新建云函数。

原因：原项目已经存在活动报名提交云函数 `submitActivityRegistration`，以及管理员查询云函数 `getAdminActivityRegistrations`。本次只是在现有数据链路中扩展字段，保持原交互和原数据集合 `activity_registrations` 不变。

## 涉及云函数

需要重新上传/部署以下已有云函数完整文件夹：

- `miniprogram/cloudfunctions/submitActivityRegistration/`
- `miniprogram/cloudfunctions/getAdminActivityRegistrations/`
- `miniprogram/cloudfunctions/getMyActivityRegistrations/`

## 主要改动文件

- `miniprogram/pages/activity/activity.wxml`
- `miniprogram/pages/activity/activity.js`
- `miniprogram/pages/activity/activity.wxss`
- `miniprogram/utils/activityRegistration.js`
- `miniprogram/pages/admin/admin.wxml`
- `miniprogram/pages/admin/admin.js`
- `miniprogram/cloudfunctions/submitActivityRegistration/index.js`
- `miniprogram/cloudfunctions/getAdminActivityRegistrations/index.js`
- `miniprogram/cloudfunctions/getMyActivityRegistrations/index.js`

## 数据字段

活动报名记录新增字段：

- `participantName`：报名姓名
- `hasChild`：是否带小孩，布尔值
- `hasChildText`：展示文案，`带小孩` / `不带小孩`

旧数据没有这些字段时，管理员端会兼容展示，不影响原有活动报名记录读取。
