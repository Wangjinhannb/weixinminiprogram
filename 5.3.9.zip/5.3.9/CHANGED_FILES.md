# 新增 / 修改 / 删除 文件清单

## 新增文件
- README.md
- DELIVERY_NOTES.md
- CHANGED_FILES.md
- miniprogram/pages/admin_venues/admin_venues.js
- miniprogram/pages/admin_venues/admin_venues.json
- miniprogram/pages/admin_venues/admin_venues.wxml
- miniprogram/pages/admin_venues/admin_venues.wxss
- miniprogram/pages/admin_venue_form/admin_venue_form.js
- miniprogram/pages/admin_venue_form/admin_venue_form.json
- miniprogram/pages/admin_venue_form/admin_venue_form.wxml
- miniprogram/pages/admin_venue_form/admin_venue_form.wxss
- miniprogram/cloudfunctions/getAvailableVenues/index.js
- miniprogram/cloudfunctions/getAdminVenues/index.js
- miniprogram/cloudfunctions/saveVenue/index.js
- miniprogram/cloudfunctions/toggleVenueStatus/index.js
- miniprogram/cloudfunctions/toggleVenueVisible/index.js
- miniprogram/cloudfunctions/deleteVenue/index.js
- miniprogram/cloudfunctions/initVenueData/index.js
- 以上新增云函数目录内对应的 package.json / config.json / _shared/bookingService.js

## 修改文件
- miniprogram/app.json
- miniprogram/utils/config.js
- miniprogram/utils/bookingApi.js
- miniprogram/pages/book/book.js
- miniprogram/pages/book/book.wxml
- miniprogram/pages/book/book.wxss
- miniprogram/pages/booking_form/booking_form.js
- miniprogram/pages/booking_form/booking_form.wxml
- miniprogram/pages/admin/admin.js
- miniprogram/pages/admin/admin.wxml
- miniprogram/cloudfunctions/_shared/bookingService.js
- miniprogram/cloudfunctions/createBooking/index.js
- miniprogram/cloudfunctions/getVenueDayBookings/index.js
- miniprogram/cloudfunctions/getMyBookings/index.js
- miniprogram/cloudfunctions/getBookingDetail/index.js
- miniprogram/cloudfunctions/getAdminBookings/index.js
- miniprogram/cloudfunctions/updateBooking/index.js
- miniprogram/cloudfunctions/cancelBooking/index.js
- miniprogram/cloudfunctions/updateBookingStatus/index.js
- miniprogram/cloudfunctions/syncUser/index.js
- 各云函数目录下的 _shared/bookingService.js 同步副本

## 删除文件
- 无物理删除；仅替换旧写死场室逻辑的数据来源。

## 2026-04-20 默认头像 + 随机昵称增量补丁
### 新增文件
- miniprogram/assets/images/default-avatar.jpg
- miniprogram/utils/profile.js
- DELIVERY_INCREMENTAL_DEFAULT_AVATAR_RANDOM_NICKNAME_20260420.md

### 修改文件
- miniprogram/utils/storage.js
- miniprogram/utils/auth.js
- miniprogram/pages/login/login.js
- miniprogram/pages/login/login.wxml
- miniprogram/pages/login/login.wxss
- miniprogram/pages/my/my.js
- miniprogram/pages/my/my.wxml
- miniprogram/pages/my/my.wxss
- miniprogram/cloudfunctions/syncUser/index.js
- 预订相关云函数的 _shared/bookingService.js（统一脱敏 avatarUrl 返回）

## 2026-04-20 管理员权限机制增量补丁
### 新增文件
- DELIVERY_ADMIN_PERMISSION_INCREMENTAL_20260420.md
- miniprogram/pages/admin_users/admin_users.js
- miniprogram/pages/admin_users/admin_users.json
- miniprogram/pages/admin_users/admin_users.wxml
- miniprogram/pages/admin_users/admin_users.wxss
- miniprogram/cloudfunctions/getAdminUsers/index.js
- miniprogram/cloudfunctions/getAdminUsers/package.json
- miniprogram/cloudfunctions/getAdminUsers/config.json
- miniprogram/cloudfunctions/setUserAdminPermission/index.js
- miniprogram/cloudfunctions/setUserAdminPermission/package.json
- miniprogram/cloudfunctions/setUserAdminPermission/config.json

### 修改文件
- miniprogram/app.json
- miniprogram/utils/storage.js
- miniprogram/utils/userSession.js
- miniprogram/utils/bookingApi.js
- miniprogram/pages/my/my.js
- miniprogram/pages/my/my.wxml
- miniprogram/pages/admin/admin.js
- miniprogram/pages/admin/admin.wxml
- miniprogram/cloudfunctions/_shared/bookingService.js
- miniprogram/cloudfunctions/syncUser/index.js
- 所有云函数目录下同步后的 _shared/bookingService.js
