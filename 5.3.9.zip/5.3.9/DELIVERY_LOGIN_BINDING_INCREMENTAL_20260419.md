# 微信/手机号双登录与账号绑定增量交付说明（2026-04-19）

## 1. 本次修改的页面/文件清单

### 前端页面
- `miniprogram/pages/my/my.js`
- `miniprogram/pages/my/my.wxml`
- `miniprogram/pages/my/my.wxss`
- `miniprogram/pages/login/login.js`（新增，轻量登录/绑定页）
- `miniprogram/pages/login/login.json`（新增）
- `miniprogram/pages/login/login.wxml`（新增）
- `miniprogram/pages/login/login.wxss`（新增）
- `miniprogram/pages/booking_form/booking_form.js`（增量补充手机号/昵称预填）

### 前端工具/配置
- `miniprogram/utils/storage.js`
- `miniprogram/utils/init.js`
- `miniprogram/utils/userSession.js`
- `miniprogram/utils/auth.js`（新增）
- `miniprogram/app.json`

### 云函数 / 后端
- `miniprogram/cloudfunctions/syncUser/index.js`

## 2. 登录页前端代码
- 已新增轻量登录页：`miniprogram/pages/login/*`
- 支持两种入口：
  - 微信登录
  - 手机号登录
- 支持绑定场景复用：
  - `scene=bind&mode=wechat`
  - `scene=bind&mode=phone`

## 3. “我的”页面前端代码
- 已在 `miniprogram/pages/my/*` 中完成增量改造
- 账号卡片支持根据绑定状态显示：
  - 微信头像
  - 微信昵称
  - 手机号
  - 绑定手机号入口
  - 绑定微信入口
- 已移除前端对 `userId/openid/unionid` 的直接展示

## 4. 账号绑定相关前端代码
- `miniprogram/utils/auth.js`
  - `loginWithWechat`
  - `loginWithPhone`
  - `bindWechat`
  - `bindPhone`
  - `uploadAvatarIfNeeded`
- `pages/login/login.js`
  - 登录/绑定两用
- `pages/my/my.js`
  - “绑定手机号”按钮
  - “绑定微信”入口

## 5. 修改后的云函数/后端代码
- `miniprogram/cloudfunctions/syncUser/index.js`
- 已扩展统一 action：
  - `refresh`
  - `wechatLogin`
  - `phoneLogin`
  - `bindPhone`
  - `bindWechat`
- 已实现：
  - 当前微信身份识别
  - 手机号凭证换号
  - 手机号唯一性校验
  - 当前微信身份唯一性校验
  - 同账号补全绑定，不重复建号
  - 统一错误码/错误消息返回

## 6. 用户数据结构兼容方案

本次没有推翻 `users` 集合，仅做平滑扩展，兼容老字段：

建议/已兼容字段：
- `userId`：继续沿用现有主账号标识（当前项目仍兼容以 OPENID 为主）
- `loginType`：`wechat` / `phone`
- `phone`
- `wechatOpenId`
- `unionId`
- `avatarUrl`
- `nickName`
- `isPhoneBound`
- `isWechatBound`
- `profileCompleted`
- `lastLoginAt`
- `updatedAt`
- `createTime`

老用户没有这些字段时：
- 前端通过 `storage.normalizeUser` 做默认值兜底
- 云函数 `refresh` 会自动补写缺失的布尔状态字段
- 不影响原有 `bookings.userId`、订单/预约等关联数据

## 7. 微信登录与手机号登录的数据流转说明

### 微信登录
1. 用户进入“我的”页或登录页，选择“微信登录”
2. 前端可选采集头像/昵称（头像会先上传云存储）
3. 前端调用 `syncUser({ action: 'wechatLogin', nickName, avatarUrl })`
4. 云函数按当前 `OPENID` 查找现有账号
5. 若存在则更新账号；不存在则在现有 `users` 集合内创建
6. 返回统一用户资料，写入本地 storage
7. “我的”页显示微信头像、微信昵称、手机号（若未绑定则提示绑定）

### 手机号登录
1. 用户选择“手机号登录”
2. 前端通过 `open-type=getPhoneNumber` 获取 `code`
3. 前端调用 `syncUser({ action: 'phoneLogin', phoneCode: code })`
4. 云函数按当前 `OPENID` 和手机号校验账号关系
5. 若当前账号存在则补全手机号；若不存在则在现有 `users` 集合创建/补全当前账号
6. 返回统一用户资料，写入本地 storage
7. “我的”页默认仅显示手机号，微信头像/昵称为空，并显示“绑定微信”入口

## 8. 账号绑定与账号归并逻辑说明

### 场景 A：微信登录后绑定手机号
- 当前账号先通过 `wechatLogin` 建立/识别
- 在“我的”页点击“去绑定手机号”
- 前端触发 `bindPhone`
- 云函数校验手机号是否已被其他账号占用
- 未冲突则将手机号补到当前账号
- 不新建用户

### 场景 B：手机号登录后绑定微信
- 当前账号先通过 `phoneLogin` 建立/识别
- 在“我的”页点击“绑定微信”
- 进入登录页绑定模式，上传头像/填写昵称
- 前端调用 `bindWechat`
- 云函数将微信资料补到当前账号
- 不新建用户

## 9. 冲突校验逻辑说明

已在云函数中做后端二次校验：

- 当前 `OPENID` 若匹配到多个账号：返回 409
- 当前手机号若匹配到多个账号：返回 409
- 当前账号绑定手机号时，若手机号已被其他账号占用：返回 409
- 手机号登录时，若手机号已绑定其他账号且不是当前微信身份：返回 409
- 前端仅展示友好提示，不以前端判断替代后端校验

## 10. 历史数据兼容方案

- 老用户原先只有：
  - `userId`
  - `nickName`
  - `avatarUrl`
  - `isAdmin`
  - `canEnterAdmin`
- 新代码会自动兼容缺省字段：
  - 默认 `isPhoneBound=false`
  - 默认 `isWechatBound` 依据老昵称/头像推断
  - 默认 `phone=''`
  - 默认 `loginType` 依据现有状态推断
- 历史预约记录仍使用原 `userId` 关联，不需要改表
- 原管理员白名单判断逻辑保留

## 11. 测试步骤

### 用例 1：微信登录新用户
1. 清空本地 storage
2. 进入“我的”页
3. 点击“微信登录”
4. 选择头像 / 输入昵称（也可不填，验证兼容）
5. 登录成功后检查：
   - 显示微信头像
   - 显示微信昵称（或“微信用户”）
   - 手机号显示“未绑定”
   - 出现“去绑定手机号”按钮

### 用例 2：微信登录后绑定手机号
1. 在上述账号中点击“去绑定手机号”
2. 授权手机号
3. 检查：
   - 不新增新账号
   - 当前账号手机号更新成功
   - 页面立即刷新展示手机号

### 用例 3：手机号登录新用户
1. 退出登录
2. 进入“我的”页 -> 手机号登录
3. 授权手机号
4. 检查：
   - 显示手机号
   - 微信头像为空
   - 微信昵称显示“未绑定”
   - 出现“绑定微信”入口

### 用例 4：手机号登录后绑定微信
1. 点击“绑定微信”
2. 选择头像 / 输入昵称
3. 检查：
   - 当前账号更新微信头像与昵称
   - 手机号保留
   - 不新增新账号

### 用例 5：手机号冲突
1. 先用账号 A 绑定手机号 X
2. 用账号 B 尝试登录/绑定手机号 X
3. 检查：
   - 后端返回 409
   - 前端提示“该手机号已绑定其他账号”或对应提示

### 用例 6：取消授权
1. 手机号授权弹窗点击取消
2. 检查：
   - 页面不崩溃
   - 显示“你已取消手机号授权”

## 12. 部署说明

### 需要重新部署的内容
- 小程序前端代码
- 云函数 `syncUser`

### 云开发侧注意事项
- 确保小程序已认证，并具备手机号能力
- `chooseAvatar` 返回的是临时文件，前端已增加上传云存储逻辑
- 若需更严格约束，后续可在 `users.phone`、`users.wechatOpenId` 维度增加数据库侧唯一性策略（当前代码已做业务层唯一校验）

## 13. 本次交付结论

本次已按“增量优化开发”方式完成：
- 未推翻现有项目
- 未重构成新系统
- 保留原有预约/管理员/用户集合结构
- 在原项目上新增双登录、绑定与展示逻辑
- 前后端规则保持一致
