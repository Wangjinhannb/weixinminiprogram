# 增量交付说明（2026-04-21）

本次修改严格基于现有项目增量开发，未重做登录体系、未重构 users 集合、未改动超级管理员 openid 配置。

## 本次实现

1. 预约成功后触发微信订阅授权流程。
2. 订阅成功后弹出“开始前多久再次提醒”滚轮选择器。
3. 前端将订阅授权结果、模板配置、提前提醒分钟数提交到云函数保存。
4. 后端保存兼容字段，并根据预约开始时间计算真实 reminderSendAtMs / reminderSendAtText。
5. `notifyBookingSubscribers` 云函数支持两类能力：
   - 预约成功后即时发送 `BOOKING_CREATED`
   - 定时扫描并发送开始前提醒 `BOOKING_REMINDER`
6. 改期成功后显示成功并自动返回上一页；同时后端自动重算原订阅的提醒发送时间。
7. 取消预约成功后：
   - 后端真实更新 bookings.status=cancelled
   - 我的页面即时把当前预约移除，并插入历史记录
   - 取消后的提醒任务自动停发

## 需要在云开发控制台补的一步

请为 `notifyBookingSubscribers` 云函数增加 **定时触发器**，建议表达式：

```text
0 */1 * * * *
```

含义：每分钟执行一次，扫描所有 `booking_subscriptions` 中 `reminderSendStatus = pending` 且 `reminderSendAtMs <= 当前时间` 的记录，并真实发送订阅消息。

## 模板配置说明

项目已把订阅模板配置做成可增量维护形式，默认在 `miniprogram/app.js`：

- `globalData.subscribeMessageTemplates.bookingSuccess`
- `globalData.subscribeMessageTemplates.bookingReminder`

请将其中的占位模板 ID 替换为你小程序后台实际申请到的订阅模板 ID，并确保模板关键词与配置中的 `fields.key` 对应。

## 新增/兼容字段

写入 `booking_subscriptions`：

- `templateConfigMap`
- `reminderEnabled`
- `reminderLeadMinutes`
- `reminderLeadText`
- `reminderBookingStartAtMs`
- `reminderBookingStartAtText`
- `reminderBookingDate`
- `reminderBookingTimeLabel`
- `reminderSendAtMs`
- `reminderSendAtText`
- `reminderSendStatus`（pending / sent / failed / skipped / cancelled / expired / disabled）
- `reminderSentAtMs`
- `reminderLastError`

以上均为增量字段，老数据不受破坏。
