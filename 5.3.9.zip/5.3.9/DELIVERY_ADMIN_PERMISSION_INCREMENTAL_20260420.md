# 管理员权限机制增量优化交付说明（2026-04-20）

## 1. 本次改动目标

在现有微信小程序项目基础上做增量优化，完成以下调整：

- 保留现有登录体系、users 集合、我的页面、管理端入口、云函数和 UI 风格
- 保留“超级管理员 openid”最高权限逻辑
- 移除“普通管理员硬编码白名单”做法
- 改为通过 users 集合字段 `isAdmin` / `canEnterAdmin` 驱动普通管理员权限
- 前后端统一使用真实权限校验，避免仅前端展示控制
- 兼容历史 users 数据，不改主键，不破坏预约/记录/资料等关联关系

## 2. 权限规则

### 超级管理员

- 当前固定超级管理员 openid：`oxeRu3XlI7a7K-8Ah6-puofWTEBo`
- 超级管理员不依赖 users 集合中的 `isAdmin` / `canEnterAdmin`
- 超级管理员永远可以进入后台
- 超级管理员可以管理普通管理员权限

### 普通管理员

- 普通管理员不再由代码数组维护
- 只要 users 集合中某用户满足以下任一条件，即拥有后台访问权限：
  - `isAdmin = true`
  - `canEnterAdmin = true`
- 新增/移除普通管理员只需改 users 数据，无需改代码和重新发布

### 优先级

1. 若 `openid === SUPER_ADMIN_OPENID`，则为超级管理员
2. 否则读取 users 集合中的 `isAdmin` / `canEnterAdmin`
3. 超级管理员权限高于普通管理员
4. 普通管理员不等于超级管理员

## 3. 核心实现

### 云端统一权限判断

已在 `miniprogram/cloudfunctions/_shared/bookingService.js` 中统一封装：

- `SUPER_ADMIN_OPENID`
- `isSuperAdminOpenId(openId)`
- `buildPermissionProfile({ user, openId })`
- `getUserPermissionByUserId(userId)`
- `assertAdminUser(userId)`
- `assertSuperAdminUser(userId)`

并已同步覆盖到所有云函数目录下的 `_shared/bookingService.js` 副本。

### 登录/刷新返回统一权限结构

`syncUser` 云函数已改为返回：

- `canEnterAdmin`
- `isAdmin`
- `isSuperAdmin`
- `canManageAdmins`
- `adminRole`
- `permission`

同时保留现有 userId / phone / loginType / 绑定状态等返回结构。

### 关键后端接口二次校验

后台相关接口仍由云函数后端校验，不依赖前端：

- `getAdminBookings`
- `getAdminVenues`
- `saveVenue`
- `toggleVenueStatus`
- `toggleVenueVisible`
- `deleteVenue`
- `initVenueData`
- 以及详情等需要管理员访问的接口

本次新增：

- `getAdminUsers`：仅超级管理员可查询用户/管理员列表
- `setUserAdminPermission`：仅超级管理员可授予/移除普通管理员权限

## 4. 前端增量改动

### 我的页面

- 保持原页面结构不推翻
- 账号身份显示改为：
  - 超级管理员
  - 普通管理员
  - 普通用户
- “进入管理员模式”按钮改为基于最新权限结构控制

### 管理页

- 仍保留原管理页
- 管理员可进入后台查看预约和场室管理
- 仅超级管理员可看到“管理员权限”入口

### 新增页面

- 新增 `pages/admin_users/admin_users`
- 用于超级管理员搜索用户并授予/移除普通管理员权限
- UI 风格沿用现有 card/button/pill 样式，没有推翻重做

## 5. users 数据兼容方案

本次不改 users 主键和关联字段；只做兼容读取：

- 老用户没有 `isAdmin` / `canEnterAdmin`：默认按非管理员处理
- 若命中超级管理员 openid：即使 users 中没有管理员字段，也仍拥有最高权限
- 若 users 中已有 `isAdmin` / `canEnterAdmin`：继续兼容沿用
- 普通管理员授予/移除时，会同步写回：
  - `isAdmin`
  - `canEnterAdmin`

## 6. 历史数据兼容

- 不修改 `userId` 主键
- 不修改 bookings 与 users 的关联方式
- 不修改已有预约记录/资料/订单关联字段
- 不要求历史数据迁移脚本即可运行
- 已登录用户进入页面后，`syncUser` 会刷新最新权限到本地缓存

## 7. 主要修改文件

### 前端
- `miniprogram/app.json`
- `miniprogram/utils/storage.js`
- `miniprogram/utils/userSession.js`
- `miniprogram/utils/bookingApi.js`
- `miniprogram/pages/my/my.js`
- `miniprogram/pages/my/my.wxml`
- `miniprogram/pages/admin/admin.js`
- `miniprogram/pages/admin/admin.wxml`
- `miniprogram/pages/admin_users/admin_users.js`
- `miniprogram/pages/admin_users/admin_users.json`
- `miniprogram/pages/admin_users/admin_users.wxml`
- `miniprogram/pages/admin_users/admin_users.wxss`

### 云函数
- `miniprogram/cloudfunctions/_shared/bookingService.js`
- `miniprogram/cloudfunctions/syncUser/index.js`
- `miniprogram/cloudfunctions/getAdminUsers/index.js`
- `miniprogram/cloudfunctions/setUserAdminPermission/index.js`
- 所有云函数目录下同步后的 `_shared/bookingService.js`

## 8. 测试步骤

### 用例 1：超级管理员登录
1. 使用超级管理员 openid 对应账号登录
2. 进入“我的”页，确认身份显示为“超级管理员”
3. 点击“进入管理员模式”
4. 确认可见：
   - 场室管理
   - 管理员权限

### 用例 2：普通管理员登录
1. 在 users 中将目标用户设置为：`isAdmin=true` 或 `canEnterAdmin=true`
2. 登录该账号
3. 进入“我的”页，确认身份显示为“普通管理员”
4. 进入后台，确认：
   - 可以进入管理页
   - 可以进入场室管理
   - 看不到“管理员权限”入口

### 用例 3：普通用户登录
1. 使用未命中超级管理员 openid，且 users 中无管理员字段的账号登录
2. 进入“我的”页，确认身份显示为“普通用户”
3. 确认不可见或不可进入后台入口

### 用例 4：超级管理员授予普通管理员
1. 超级管理员进入“管理员权限”页
2. 搜索目标用户
3. 点击“设为管理员”
4. 检查 users 集合：
   - `isAdmin = true`
   - `canEnterAdmin = true`
5. 目标用户重新进入页面后可进入后台

### 用例 5：超级管理员移除普通管理员
1. 超级管理员进入“管理员权限”页
2. 找到目标普通管理员
3. 点击“移除管理员”
4. 检查 users 集合：
   - `isAdmin = false`
   - `canEnterAdmin = false`
5. 目标用户重新进入页面后不可进入后台

### 用例 6：后端绕过校验验证
1. 用普通用户账号直接调用后台云函数（如 `getAdminBookings`）
2. 确认返回“仅管理员可访问”
3. 用普通管理员账号直接调用 `setUserAdminPermission`
4. 确认返回“仅超级管理员可访问”

## 9. 部署说明

需要重新上传/部署：

### 小程序前端
- 整个 `miniprogram` 前端代码

### 云函数
- `syncUser`
- `getAdminUsers`
- `setUserAdminPermission`
- 以及所有引用 `_shared/bookingService.js` 的现有云函数（因为权限共享逻辑已统一更新）

## 10. 注意事项

- 当前超级管理员 openid 固定写在共享权限模块中，便于集中维护
- 普通管理员已改为数据库驱动，不再需要改代码白名单
- 若历史上曾依赖旧白名单中的普通管理员账号，请在 users 集合中为该用户补充 `isAdmin=true` 或 `canEnterAdmin=true`
