Page({  
  onShow:function(){ try{ this.setData({ uiFontSizePx: getApp().globalData.uiFontSizePx||16 }); 
    var tb = this.getTabBar && this.getTabBar();
    if (tb && tb.syncFont) tb.syncFont();
}catch(e){} }
});
