var statusText = require('../../utils/ui').statusText;
var bookingApi = require('../../utils/bookingApi');
var ui = require('../../utils/ui');
var storage = require('../../utils/storage');
var userSession = require('../../utils/userSession');
var auth = require('../../utils/auth');
var profile = require('../../utils/profile');
var subscriptionUtil = require('../../utils/subscription');

function getUserViewModel(user) {
  user = storage.normalizeUser(user || storage.getUser());
  var loginTypeText = '未登录';
  if (user.loginType === 'wechat') loginTypeText = '微信登录';
  else if (user.loginType === 'phone') loginTypeText = '手机号登录';
  else if (user.userId) loginTypeText = user.isWechatBound ? '微信登录' : '手机号登录';

  var adminRoleText = user.isSuperAdmin ? '超级管理员' : (user.canEnterAdmin ? '普通管理员' : '普通用户');
  var adminHint = user.isSuperAdmin
    ? '当前账号拥有最高后台权限，可进入后台并管理普通管理员权限。'
    : (user.canEnterAdmin
      ? '当前账号可进入管理员模式。'
      : '当前账号暂无后台权限。');

  return {
    loginTypeText: loginTypeText,
    showWechatProfile: !!user.isWechatBound,
    displayName: user.isWechatBound ? (user.nickName || '微信用户') : (user.phone || user.phoneMask || '手机号用户'),
    avatarDisplayUrl: user.isWechatBound ? (user.avatarDisplayUrl || profile.getDefaultAvatarUrl()) : '',
    phoneText: user.phone || '未绑定',
    nickNameText: user.isWechatBound ? (user.nickName || '微信用户') : '未绑定',
    adminRoleText: adminRoleText,
    adminHint: adminHint,
    showBindPhone: !!user.userId && user.isWechatBound && !user.isPhoneBound,
    showBindWechat: !!user.userId && !user.isWechatBound,
    profileHint: user.isWechatBound
      ? (user.isPhoneBound
        ? '当前账号已完成微信和手机号绑定。'
        : '当前账号已绑定微信；如需补全联系信息，可继续绑定手机号。')
      : '当前为手机号登录；绑定微信后将统一展示默认头像。'
  };
}

function buildSubscriptionContext(booking, acceptResultMap) {
  return {
    booking: booking,
    tmplIds: subscriptionUtil.getRequestTemplateIds(),
    acceptResultMap: acceptResultMap || {},
    templateConfigMap: subscriptionUtil.getTemplateConfigMap()
  };
}

Page({
  data: {
    statusText: statusText,
    uiFontSizePx: 16,
    user: null,
    userView: {},
    list: [],
    activeBooking: null,
    historyList: [],
    subscriptionMap: {},
    bindingPhone: false,
    reminderModalVisible: false,
    reminderBooking: null,
    reminderDefaultLeadMinutes: 30,
    pendingSubscriptionContext: null,
    subscriptionSaving: false
  },

  onShow: function() {
    var that = this;
    try {
      this.setData({ uiFontSizePx: getApp().globalData.uiFontSizePx || 16 });
      var tb = this.getTabBar && this.getTabBar();
      if (tb) {
        if (tb.setSelectedByPath) tb.setSelectedByPath('/pages/my/my');
        if (tb.syncFont) tb.syncFont();
      }
    } catch(e) {}
    var currentUser = storage.getUser();
    this.syncUserState(currentUser);
    userSession.refreshCurrentUser({ user: currentUser, silent: true }).then(function(syncRes) {
      if (syncRes && syncRes.user) that.syncUserState(syncRes.user);
      if (syncRes && syncRes.adminChanged) {
        ui.toast(syncRes.user && syncRes.user.canEnterAdmin ? '管理员权限已同步更新' : '管理员权限已更新');
      }
    }).catch(function(err) {
      console.error('静默同步用户失败', err);
    }).finally(function() {
      that.reload();
    });
  },

  syncUserState: function(user) {
    user = storage.normalizeUser(user || storage.getUser());
    this.setData({
      user: user,
      userView: getUserViewModel(user)
    });
  },

  goLogin: function(e) {
    var mode = (e && e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.mode) || 'wechat';
    wx.navigateTo({ url: '/pages/login/login?mode=' + encodeURIComponent(mode) });
  },

  goBindWechat: function() {
    wx.navigateTo({ url: '/pages/login/login?scene=bind&mode=wechat' });
  },

  onBindPhone: function(e) {
    var that = this;
    var detail = e.detail || {};
    if (this.data.bindingPhone) return;
    if (!detail.code) {
      if (detail.errMsg && detail.errMsg.indexOf('deny') > -1) ui.toast('你已取消手机号授权');
      else ui.toast('未获取到手机号授权凭证');
      return;
    }
    this.setData({ bindingPhone: true });
    ui.loading('绑定中');
    auth.bindPhone(detail.code).then(function(user) {
      that.syncUserState(user);
      ui.toast('手机号绑定成功');
      that.reload();
    }).catch(function(err) {
      console.error('bind phone failed', err);
      ui.toast((err && err.message) || '手机号绑定失败');
    }).finally(function() {
      that.setData({ bindingPhone: false });
      ui.hideLoading();
    });
  },

  logout: function() {
    var that = this;
    wx.showModal({
      title: '退出登录',
      content: '确定要退出当前账号吗？',
      confirmText: '退出',
      confirmColor: '#e64340',
      success: function (res) {
        if (res.confirm) {
          var guest = auth.logout();
          that.setData({ user: guest, userView: getUserViewModel(guest), list: [], activeBooking: null, historyList: [], subscriptionMap: {} });
          ui.toast('已安全退出');
        }
      }
    });
  },

  reload: function() {
    var that = this;
    var u = storage.getUser();
    if (!u || !u.userId) {
      that.setData({ list: [], activeBooking: null, historyList: [], subscriptionMap: {} });
      return;
    }
    ui.loading('加载中');
    bookingApi.listMyBookings().then(function(list) {
      list = list || [];
      var active = null;
      var history = [];
      for (var i = 0; i < list.length; i++) {
        if (list[i].status === 'cancelled') history.push(list[i]);
        else if (!active) active = list[i];
      }
      that.setData({ list: list, activeBooking: active, historyList: history });
      var ids = [];
      if (active && active.id) ids.push(active.id);
      return bookingApi.batchGetSubscriptionStatus(ids, u.userId);
    }).then(function (map) {
      that.setData({ subscriptionMap: map || {} });
    }).catch(function(e) {
      console.error('查询我的预约失败：', e);
      ui.toast((e && e.message) || '加载失败');
    }).finally(function() { ui.hideLoading(); });
  },

  applyCancelledBooking: function(cancelledBooking) {
    cancelledBooking = cancelledBooking || {};
    if (!cancelledBooking.id) return;
    var list = (this.data.list || []).slice();
    var history = (this.data.historyList || []).slice();
    var active = this.data.activeBooking;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === cancelledBooking.id) {
        list[i] = cancelledBooking;
        break;
      }
    }
    var exists = false;
    for (var j = 0; j < history.length; j++) {
      if (history[j].id === cancelledBooking.id) {
        history[j] = cancelledBooking;
        exists = true;
        break;
      }
    }
    if (!exists) history.unshift(cancelledBooking);
    if (active && active.id === cancelledBooking.id) active = null;
    var map = this.data.subscriptionMap || {};
    delete map[cancelledBooking.id];
    this.setData({
      list: list,
      activeBooking: active,
      historyList: history,
      subscriptionMap: map
    });
  },

  applyUpdatedBooking: function(updatedBooking) {
    updatedBooking = updatedBooking || {};
    if (!updatedBooking.id) return;
    var list = (this.data.list || []).slice();
    var history = (this.data.historyList || []).slice();
    var active = this.data.activeBooking;
    var found = false;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === updatedBooking.id) {
        list[i] = updatedBooking;
        found = true;
        break;
      }
    }
    if (!found) list.unshift(updatedBooking);
    if (active && active.id === updatedBooking.id) active = updatedBooking;
    for (var j = history.length - 1; j >= 0; j--) {
      if (history[j].id === updatedBooking.id) history.splice(j, 1);
    }
    this.setData({ list: list, activeBooking: active || updatedBooking, historyList: history });
  },

  goBook: function() { wx.switchTab({ url: '/pages/book/book' }); },

  onDetail: function(e) {
    var id = (e.detail && e.detail.id) ? e.detail.id : e.currentTarget.dataset.id;
    if (!id) return ui.toast('缺少预约ID');
    wx.navigateTo({ url: '/pages/booking_detail/booking_detail?id=' + encodeURIComponent(id) });
  },

  onEdit: function(e) {
    var id = (e.detail && e.detail.id) ? e.detail.id : e.currentTarget.dataset.id;
    if (!id) return ui.toast('缺少预约ID');
    wx.navigateTo({ url: '/pages/booking_form/booking_form?edit=1&id=' + encodeURIComponent(id) });
  },

  onCancel: function(e) {
    var that = this;
    var id = (e.detail && e.detail.id) ? e.detail.id : e.currentTarget.dataset.id;
    if (!id) return ui.toast('缺少预约ID');
    wx.showModal({
      title: '取消预约',
      content: '确认取消该预约吗？',
      confirmText: '取消预约',
      confirmColor: '#e64340',
      success: function(res) {
        if (!res.confirm) return;
        ui.loading('处理中');
        bookingApi.cancelBooking(id).then(function(cancelledBooking) {
          that.applyCancelledBooking(cancelledBooking);
          ui.toast('已取消');
          that.reload();
        }).catch(function(err) {
          console.error('取消报错：', err);
          ui.toast((err && err.message) || '取消失败');
        }).finally(function() { ui.hideLoading(); });
      }
    });
  },

  onToggleBookingSubscribe: function(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    var enabled = !!e.currentTarget.dataset.enabled;
    var booking = this.data.activeBooking;
    var nextEnabled = !enabled;
    if (!id || !booking) return;
    if (!nextEnabled) {
      ui.loading('处理中');
      bookingApi.saveSubscription({ bookingId: id, enabled: false, reminderEnabled: false }).then(function() {
        var map = that.data.subscriptionMap || {};
        map[id] = false;
        that.setData({ subscriptionMap: map });
        ui.toast('已取消订阅');
      }).catch(function(err) {
        ui.toast((err && err.message) || '操作失败');
      }).finally(function() { ui.hideLoading(); });
      return;
    }
    if (!subscriptionUtil.isTemplateConfigReady()) {
      ui.toast('请先在 app.js 配置订阅消息模板 ID');
      return;
    }
    var ids = subscriptionUtil.getRequestTemplateIds();
    wx.requestSubscribeMessage({
      tmplIds: ids,
      success: function(res) {
        if (!subscriptionUtil.hasAcceptedTemplate(res || {})) {
          ui.toast('未同意订阅，可稍后再次开启');
          return;
        }
        that.setData({
          reminderModalVisible: true,
          reminderBooking: booking,
          reminderDefaultLeadMinutes: subscriptionUtil.getDefaultLeadMinutes(booking),
          pendingSubscriptionContext: buildSubscriptionContext(booking, res || {})
        });
      },
      fail: function(err) {
        ui.toast((err && err.errMsg) || '订阅授权未完成');
      }
    });
  },

  onReminderConfirm: function(e) {
    var that = this;
    var detail = e.detail || {};
    var ctx = this.data.pendingSubscriptionContext;
    if (!ctx || !ctx.booking || !ctx.booking.id) {
      this.closeReminderModal();
      return;
    }
    if (this.data.subscriptionSaving) return;
    this.setData({ subscriptionSaving: true });
    ui.loading('保存提醒中');
    bookingApi.saveSubscription({
      bookingId: ctx.booking.id,
      enabled: true,
      tmplIds: ctx.tmplIds,
      acceptResultMap: ctx.acceptResultMap,
      templateConfigMap: ctx.templateConfigMap,
      reminderEnabled: true,
      reminderLeadMinutes: detail.leadMinutes
    }).then(function() {
      var map = that.data.subscriptionMap || {};
      map[ctx.booking.id] = true;
      that.setData({ subscriptionMap: map });
      that.closeReminderModal();
      ui.toast('已订阅并设置提醒');
    }).catch(function(err) {
      ui.toast((err && err.message) || '保存提醒失败');
    }).finally(function() {
      that.setData({ subscriptionSaving: false });
      ui.hideLoading();
    });
  },

  onReminderSkip: function() {
    var that = this;
    var ctx = this.data.pendingSubscriptionContext;
    if (!ctx || !ctx.booking || !ctx.booking.id) {
      this.closeReminderModal();
      return;
    }
    if (this.data.subscriptionSaving) return;
    this.setData({ subscriptionSaving: true });
    ui.loading('保存订阅中');
    bookingApi.saveSubscription({
      bookingId: ctx.booking.id,
      enabled: true,
      tmplIds: ctx.tmplIds,
      acceptResultMap: ctx.acceptResultMap,
      templateConfigMap: ctx.templateConfigMap,
      reminderEnabled: false,
      reminderLeadMinutes: 0
    }).then(function() {
      var map = that.data.subscriptionMap || {};
      map[ctx.booking.id] = true;
      that.setData({ subscriptionMap: map });
      that.closeReminderModal();
      ui.toast('已订阅状态通知');
    }).catch(function(err) {
      ui.toast((err && err.message) || '保存订阅失败');
    }).finally(function() {
      that.setData({ subscriptionSaving: false });
      ui.hideLoading();
    });
  },

  closeReminderModal: function() {
    this.setData({
      reminderModalVisible: false,
      reminderBooking: null,
      pendingSubscriptionContext: null,
      reminderDefaultLeadMinutes: 30
    });
  },

  goAdmin: function() {
    var u = storage.getUser();
    if(!u || !u.canEnterAdmin) { ui.toast('当前账号暂无管理员权限'); return; }
    wx.navigateTo({ url: '/pages/admin/admin' });
  }
});
