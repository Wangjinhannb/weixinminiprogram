var bookingApi = require('../../utils/bookingApi');
var ui = require('../../utils/ui');
var dateUtil = require('../../utils/date');

function buildTimePoints() {
  var list = [];
  for (var h = 8; h <= 22; h++) {
    var hh = h < 10 ? ('0' + h) : ('' + h);
    list.push(hh + ':00');
    if (h !== 22) list.push(hh + ':30');
  }
  return list;
}

function toMin(t) {
  var arr = String(t || '').split(':');
  return Number(arr[0] || 0) * 60 + Number(arr[1] || 0);
}

function isOverlap(startA, endA, startB, endB) {
  return toMin(startA) < toMin(endB) && toMin(endA) > toMin(startB);
}

function buildSlotList(points, occupiedList) {
  var rows = [];
  occupiedList = occupiedList || [];
  for (var i = 0; i < points.length - 1; i++) {
    var startTime = points[i];
    var endTime = points[i + 1];
    var occupied = false;
    for (var j = 0; j < occupiedList.length; j++) {
      if (isOverlap(startTime, endTime, occupiedList[j].startTime, occupiedList[j].endTime)) {
        occupied = true;
        break;
      }
    }
    rows.push({
      id: 'slot_' + i,
      label: startTime + ' - ' + endTime,
      statusText: occupied ? '已占用' : '可预约',
      statusClass: occupied ? 'slot-occupied' : 'slot-free'
    });
  }
  return rows;
}

Page({
  data: {
    uiFontSizePx: 16,
    venues: [],
    venueNames: [],
    venueIndex: 0,
    currentVenue: null,
    date: '',
    dateStart: '',
    dateEnd: '',
    loading: false,
    queried: false,
    queryError: '',
    occupiedList: [],
    occupiedTextList: [],
    slotList: [],
    timePoints: buildTimePoints()
  },

  onShow: function () {
    try {
      this.setData({ uiFontSizePx: getApp().globalData.uiFontSizePx || 16 });
      var tb = this.getTabBar && this.getTabBar();
      if (tb) {
        if (tb.setSelectedByPath) tb.setSelectedByPath('/pages/schedule/schedule');
        if (tb.syncFont) tb.syncFont();
      }
    } catch (e) {}
  },

  onLoad: function () {
    var today = dateUtil.fmtDate(new Date());
    this.setData({
      date: today,
      dateStart: today,
      dateEnd: dateUtil.fmtDate(dateUtil.addDays(new Date(), 60))
    });
    this.loadVenuesAndRefresh();
  },

  loadVenuesAndRefresh: function () {
    var that = this;
    ui.loading('加载中');
    bookingApi.listVenues().then(function (venues) {
      venues = venues || [];
      that.setData({
        venues: venues,
        venueNames: venues.map(function (v) { return v.name; }),
        venueIndex: 0,
        currentVenue: venues[0] || null
      });
      that.querySchedule();
    }).catch(function (e) {
      that.setData({ queried: true, queryError: (e && e.message) || '加载场室失败', occupiedList: [], occupiedTextList: [], slotList: [] });
      ui.toast((e && e.message) || '加载失败');
    }).finally(function () { ui.hideLoading(); });
  },

  onVenueChange: function (e) {
    var idx = Number(e.detail.value || 0);
    this.setData({ venueIndex: idx, currentVenue: (this.data.venues || [])[idx] || null });
    this.querySchedule();
  },

  onDateChange: function (e) {
    this.setData({ date: e.detail.value || '' });
    this.querySchedule();
  },

  onRetry: function () {
    this.querySchedule();
  },

  querySchedule: function () {
    var that = this;
    var venue = this.data.currentVenue;
    var date = this.data.date;
    if (!venue || !date) {
      that.setData({ queried: true, queryError: '请先选择场室和日期', occupiedList: [], occupiedTextList: [], slotList: [] });
      return;
    }

    that.setData({ loading: true, queried: false, queryError: '' });
    bookingApi.listVenueDayBookings(venue.id, date, false).then(function (list) {
      list = list || [];
      var occupiedTextList = [];
      for (var i = 0; i < list.length; i++) {
        occupiedTextList.push(list[i].timeLabel || (list[i].startTime + ' - ' + list[i].endTime));
      }
      that.setData({
        queried: true,
        queryError: '',
        occupiedList: list,
        occupiedTextList: occupiedTextList,
        slotList: buildSlotList(that.data.timePoints, list)
      });
    }).catch(function (e) {
      console.error('查询时间表失败：', e);
      that.setData({ queried: true, queryError: (e && e.message) || '加载时间表失败', occupiedList: [], occupiedTextList: [], slotList: [] });
      ui.toast((e && e.message) || '加载失败');
    }).finally(function () {
      that.setData({ loading: false });
    });
  }
});
