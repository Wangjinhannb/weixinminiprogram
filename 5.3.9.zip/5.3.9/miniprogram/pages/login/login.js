var ui = require('../../utils/ui');
var auth = require('../../utils/auth');
var storage = require('../../utils/storage');
var profile = require('../../utils/profile');

Page({
  data: {
    uiFontSizePx: 16,
    scene: 'login',
    mode: 'wechat',
    submitting: false,
    user: null,
    defaultAvatarUrl: profile.getDefaultAvatarUrl()
  },

  onLoad: function (options) {
    options = options || {};
    var scene = options.scene === 'bind' ? 'bind' : 'login';
    var mode = options.mode === 'phone' ? 'phone' : 'wechat';
    var user = storage.getUser();
    if (scene === 'bind' && (!user || !user.userId)) {
      ui.toast('请先登录后再进行绑定');
      wx.switchTab({ url: '/pages/my/my' });
      return;
    }
    this.setData({
      uiFontSizePx: (getApp().globalData && getApp().globalData.uiFontSizePx) || 16,
      scene: scene,
      mode: mode,
      user: user,
      defaultAvatarUrl: profile.getDefaultAvatarUrl()
    });
  },

  onShow: function () {
    try {
      this.setData({
        uiFontSizePx: getApp().globalData.uiFontSizePx || 16,
        defaultAvatarUrl: profile.getDefaultAvatarUrl()
      });
    } catch (e) {}
  },

  switchMode: function (e) {
    if (this.data.submitting) return;
    var mode = e.currentTarget.dataset.mode || 'wechat';
    this.setData({ mode: mode });
  },

  submitWechat: function () {
    var that = this;
    if (this.data.submitting) return;
    this.setData({ submitting: true });
    ui.loading(this.data.scene === 'bind' ? '绑定中' : '登录中');
    var req = this.data.scene === 'bind'
      ? auth.bindWechat()
      : auth.loginWithWechat();

    req.then(function () {
      ui.toast(that.data.scene === 'bind' ? '微信绑定成功' : '登录成功');
      that.goBackSoon();
    }).catch(function (err) {
      console.error('submitWechat error', err);
      ui.toast((err && err.message) || (that.data.scene === 'bind' ? '绑定失败' : '登录失败'));
    }).finally(function () {
      that.setData({ submitting: false });
      ui.hideLoading();
    });
  },

  onPhoneAuth: function (e) {
    var that = this;
    if (this.data.submitting) return;
    var detail = e.detail || {};
    if (!detail.code) {
      if (detail.errMsg && detail.errMsg.indexOf('deny') > -1) {
        ui.toast('你已取消手机号授权');
      } else {
        ui.toast('未获取到手机号授权凭证');
      }
      return;
    }
    this.setData({ submitting: true });
    ui.loading(this.data.scene === 'bind' ? '绑定中' : '登录中');
    var req = this.data.scene === 'bind' ? auth.bindPhone(detail.code) : auth.loginWithPhone(detail.code);
    req.then(function () {
      ui.toast(that.data.scene === 'bind' ? '手机号绑定成功' : '登录成功');
      that.goBackSoon();
    }).catch(function (err) {
      console.error('onPhoneAuth error', err);
      ui.toast((err && err.message) || (that.data.scene === 'bind' ? '绑定失败' : '登录失败'));
    }).finally(function () {
      that.setData({ submitting: false });
      ui.hideLoading();
    });
  },

  goBackSoon: function () {
    var scene = this.data.scene;
    setTimeout(function () {
      if (scene === 'bind') {
        wx.navigateBack({ delta: 1, fail: function () { wx.switchTab({ url: '/pages/my/my' }); } });
      } else {
        wx.switchTab({ url: '/pages/my/my' });
      }
    }, 300);
  },

  goBack: function () {
    if (this.data.scene === 'bind') {
      wx.navigateBack({ delta: 1, fail: function () { wx.switchTab({ url: '/pages/my/my' }); } });
    } else {
      wx.switchTab({ url: '/pages/my/my' });
    }
  }
});
