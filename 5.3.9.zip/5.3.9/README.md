# booking_system_venue_admin_upgrade

基于现有微信小程序预约系统完成二次开发，新增“管理员可配置并发布哪些场室可预约”功能。

请优先阅读 `DELIVERY_NOTES.md` 获取交付说明、部署步骤、迁移方案与测试步骤。
