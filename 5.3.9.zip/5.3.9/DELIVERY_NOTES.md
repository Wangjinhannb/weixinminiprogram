# 预约系统二次开发交付说明

## 1. 方案概述
- 保留原有预约流程、原有页面风格、原有云函数调用方式。
- 将前端和云函数中写死的场室配置迁移为 `venues` 集合驱动。
- 新增管理员“场室管理”页面和 7 个场室管理相关云函数。
- 历史预约继续通过 `bookings.venueName` / `bookings.venueSnapshot` 展示，避免因场室被隐藏、停用、删除而无法查看。

## 2. 数据结构设计

### venues 集合
建议文档结构：
```json
{
  "_id": "",
  "venueId": "room_a",
  "name": "多功能会议室",
  "description": "可容纳20人，适合会议",
  "location": "3楼301",
  "capacity": 20,
  "visible": true,
  "enabled": true,
  "deleted": false,
  "sort": 10,
  "timeSlots": [
    { "start": "09:00", "end": "10:00", "label": "09:00-10:00" },
    { "start": "10:00", "end": "11:00", "label": "10:00-11:00" }
  ],
  "bookingNotice": "请提前10分钟到场",
  "features": ["WiFi", "投影"],
  "createdAt": "",
  "updatedAt": "",
  "updatedBy": "管理员ID"
}
```

### bookings 集合
兼容原有结构，至少包括：
- `userId`
- `venueId`
- `venueName`
- `venueSnapshot`（新增，建议保留场室快照）
- `date`
- `startTime`
- `endTime`
- `timeLabel`
- `status`
- `form`

### users 集合
沿用原集合，继续使用 `isAdmin`、`canEnterAdmin` 字段。管理员校验统一为：
1. OPENID 白名单；
2. 或 `users` 集合中已有 `isAdmin/canEnterAdmin = true`。

## 3. 接口设计

### 普通用户云函数
- `getAvailableVenues`：获取 `visible=true && enabled=true && deleted=false` 的场室。
- `getVenueDayBookings`：获取指定场室某日已占用时间段。
- `createBooking`：创建预约，并做场室合法性与冲突校验。
- `getBookingDetail`：查看预约详情。
- `getMyBookings`：查看我的预约列表。

### 管理员云函数
- `getAdminVenues`：查看全部场室。
- `saveVenue`：新增/编辑场室。
- `toggleVenueStatus`：启用/停用预约。
- `toggleVenueVisible`：展示/隐藏场室。
- `deleteVenue`：软删除场室。
- `getAdminBookings`：查看全部预约。
- `initVenueData`：把旧写死场室初始化到 `venues` 集合（仅当集合为空时插入）。

## 4. 前端页面与状态设计

### pages/book/book
页面 `data` 重点字段：
- `venues`：后端读取的可预约场室列表
- `venueNames`：picker 选项
- `currentVenue`：当前选中场室
- `features`：标签展示
- `loading` / `emptyText`：加载与空态

### pages/booking_form/booking_form
页面 `data` 重点字段：
- `venue`：当前场室对象（含 timeSlots）
- `timeOptions`：由场室 `timeSlots` 转换出的时间轴
- `startSlotOptions` / `endSlotOptions`：可选开始/结束时间列表
- `occupiedList` / `occupiedTextList`：已占用时段
- `loadingOccupied` / `loadingVenue` / `formError`：加载态与错误态
- `form`：预约表单

### pages/admin/admin
新增“场室管理”入口，原管理员预约列表保留。

### pages/admin_venues/admin_venues
管理员场室管理页，含：
- 场室列表
- 新增按钮
- 初始化默认场室按钮
- 启用/停用
- 展示/隐藏
- 编辑
- 软删除
- 空状态、异常状态、加载态

### pages/admin_venue_form/admin_venue_form
管理员场室编辑表单页，含：
- 基础信息编辑
- 时间段编辑
- 展示/启用状态开关
- 表单校验

## 5. 需要修改的现有文件清单

### 修改
- `miniprogram/app.json`
- `miniprogram/utils/config.js`
- `miniprogram/utils/bookingApi.js`
- `miniprogram/pages/book/book.js`
- `miniprogram/pages/book/book.wxml`
- `miniprogram/pages/book/book.wxss`
- `miniprogram/pages/booking_form/booking_form.js`
- `miniprogram/pages/booking_form/booking_form.wxml`
- `miniprogram/pages/admin/admin.js`
- `miniprogram/pages/admin/admin.wxml`
- `miniprogram/cloudfunctions/_shared/bookingService.js`
- 以及各云函数目录下 `_shared/bookingService.js` 同步副本
- `miniprogram/cloudfunctions/createBooking/index.js`
- `miniprogram/cloudfunctions/getVenueDayBookings/index.js`
- `miniprogram/cloudfunctions/getMyBookings/index.js`
- `miniprogram/cloudfunctions/getBookingDetail/index.js`
- `miniprogram/cloudfunctions/getAdminBookings/index.js`
- `miniprogram/cloudfunctions/updateBooking/index.js`
- `miniprogram/cloudfunctions/cancelBooking/index.js`
- `miniprogram/cloudfunctions/updateBookingStatus/index.js`
- `miniprogram/cloudfunctions/syncUser/index.js`

### 新增
- `miniprogram/pages/admin_venues/`
- `miniprogram/pages/admin_venue_form/`
- `miniprogram/cloudfunctions/getAvailableVenues/`
- `miniprogram/cloudfunctions/getAdminVenues/`
- `miniprogram/cloudfunctions/saveVenue/`
- `miniprogram/cloudfunctions/toggleVenueStatus/`
- `miniprogram/cloudfunctions/toggleVenueVisible/`
- `miniprogram/cloudfunctions/deleteVenue/`
- `miniprogram/cloudfunctions/initVenueData/`
- `README.md`

### 删除
- 无物理删除。保留旧逻辑文件但不再作为主数据来源。

## 6. 数据迁移说明

### 旧逻辑来源
- 前端：`utils/config.js` 中写死 `venues`
- 云函数：`_shared/bookingService.js` 中写死 `VENUES`

### 迁移策略
1. 新增 `venues` 集合，作为唯一可预约场室配置来源。
2. 提供管理员云函数 `initVenueData`，仅在 `venues` 集合为空时插入旧的默认场室。
3. `bookings` 原数据不强制回写，历史预约继续依赖已有 `venueName` 展示；新预约会额外保存 `venueSnapshot`。
4. 旧代码中的场室常量保留为“初始化默认数据”和“历史名称兜底”用途，不再参与普通用户预约页展示。

## 7. 部署步骤
1. 用微信开发者工具打开 `miniprogram` 目录。
2. 在“云开发”中确认已开通环境，并将项目云环境绑定到当前小程序。
3. 云数据库创建集合：
   - `venues`
   - `bookings`
   - `users`
   - 若原项目已有通知功能，保留：`booking_subscriptions`、`booking_notifications`
4. 右键上传并部署全部云函数。
5. 先以管理员账号登录一次，确保 `users` 集合写入当前 OPENID。
6. 进入“我的”→“管理”→“场室管理”，点击“初始化默认场室”。
7. 在场室管理中按需编辑场室、发布/隐藏/停用。

## 8. 测试步骤
1. 管理员登录，进入场室管理。
2. 初始化默认场室，检查列表是否显示全部场室。
3. 新增一个场室，配置多个 `timeSlots`。
4. 将某场室设置为隐藏，普通用户预约页应看不到。
5. 将某场室设置为停用，普通用户预约页应看不到。
6. 普通用户选择已发布场室，进入预约页应只看到该场室的配置时段。
7. 提交已占用时间段应失败，并收到冲突提示。
8. 场室软删除后，历史预约详情页、我的预约、管理员预约列表仍能正常查看。

## 9. 常见问题与解决方案

### Q1：部署云函数报 `Cannot find module '../_shared/bookingService'`
本次改造已避免跨云函数相对引用，采用每个云函数目录内自带 `_shared/bookingService.js` 的方式，确保可直接部署。

### Q2：普通用户预约页没有场室
先确认：
- `venues` 集合已初始化；
- 场室 `visible=true`；
- 场室 `enabled=true`；
- 场室 `deleted=false`。

### Q3：管理员进入场室管理提示无权限
请将真实管理员 OPENID 写入 `cloudfunctions/_shared/bookingService.js` 中的 `ADMIN_USER_WHITELIST`，然后重新部署相关云函数。

### Q4：历史预约显示“已删除场室”
旧数据如果本身未保存 `venueName`，且该 `venueId` 在旧常量与新 `venues` 集合里都不存在时，会显示兜底名称；这是为了保证历史预约仍可打开。

### Q5：为什么创建预约时后端仍会报“场室当前未对外展示/暂停预约”
这是正常的后端权限与合法性校验，避免只依赖前端控制。
